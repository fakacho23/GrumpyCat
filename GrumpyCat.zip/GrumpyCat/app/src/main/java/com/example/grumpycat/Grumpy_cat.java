package com.example.grumpycat;

public class Grumpy_cat {
    private final String name;
    private final String image;

    public Grumpy_cat(String name, String image) {
        this.name = name;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public String getImage() {
        return image;
    }
}
